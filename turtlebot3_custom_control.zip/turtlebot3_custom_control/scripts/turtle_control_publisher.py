#!/usr/bin/env python3

import rospy
from turtlebot3_custom_control.msg import Command

def main():
    rospy.init_node('turtle_control_publisher', anonymous=True)
    pub = rospy.Publisher('/turtlebot3_command', Command, queue_size=10)
    rate = rospy.Rate(1)  # 1 Hz

    while not rospy.is_shutdown():
        direction = input("Enter direction (forward/backward/left/right): ").strip().lower()
        speed = float(input("Enter speed (0.1 to 1.0): "))

        if direction not in ["forward", "backward", "left", "right"]:
            rospy.logwarn("Invalid direction! Use forward, backward, left, or right.")
            continue

        msg = Command()
        msg.direction = direction
        msg.speed = speed

        rospy.loginfo(f"Publishing: {msg}")
        pub.publish(msg)
        rate.sleep()

if __name__ == "__main__":
    main()

