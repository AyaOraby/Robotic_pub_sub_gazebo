#!/usr/bin/env python3

import rospy
from turtlebot3_custom_control.msg import Command
from geometry_msgs.msg import Twist

def callback(msg):
    rospy.loginfo(f"Received command: {msg.direction} at speed {msg.speed}")

    velocity_msg = Twist()
    
    if msg.direction == "forward":
        velocity_msg.linear.x = msg.speed
    elif msg.direction == "backward":
        velocity_msg.linear.x = -msg.speed
    elif msg.direction == "left":
        velocity_msg.angular.z = msg.speed
    elif msg.direction == "right":
        velocity_msg.angular.z = -msg.speed

    pub.publish(velocity_msg)

rospy.init_node('turtle_control_subscriber')
pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
sub = rospy.Subscriber('/turtlebot3_command', Command, callback)

rospy.loginfo("Subscriber is running...")
rospy.spin()
